//
// Created by Alexe Andra on 11.04.2023.
//

#ifndef LAB_7_8_TESTE_H
#define LAB_7_8_TESTE_H
void testTranzactie();
#endif //LAB_7_8_TESTE_H
